<?php

/*
Plugin Name:  BuddyPress Group Email Notifier
Text Domain: bp_activity_posted_update
/*
Plugin Name: Mi plugin de funciones
Description: Envía correos a todos los miembros del grupo cuando se publica una nueva actividad en grupos de BuddyPress.
Version: 1.0
Author: José M. Sánchez
Author URI: https://alfeizar.net
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html
*/



add_action('bp_activity_after_save', function($activity) {
    if (
        $activity->component === 'groups' &&
        in_array($activity->type, ['activity_update', 'rtmedia_update']) &&
        $activity->id &&
        !empty($activity->content)
    ) {
        $contenido = $activity->content;
        $contenido_renderizado = '';

        if (preg_match('/\[bpfb_link.*?url=['"]([^'"]+)['"].*?(title=['"]([^'"]+)['"])?/i', $contenido, $match)) {
            $url = esc_url($match[1]);
            $titulo = isset($match[3]) ? esc_html($match[3]) : $url;
            $contenido_renderizado .= "<p><strong>🔗 Enlace compartido:</strong> <a href='$url' target='_blank'>$titulo</a></p>";
        }

        if (preg_match('/\[bpfb_video\](.*?)\[\/bpfb_video\]/i', $contenido, $match)) {
            $video = esc_url(trim($match[1]));
            $contenido_renderizado .= "<p><strong>🎥 Video de YouTube:</strong> <a href='$video' target='_blank'>$video</a></p>";
        }

        if ($activity->type === 'rtmedia_update') {
            if (preg_match('/<img.*?src=['"]([^'"]+)['"].*?>/i', $contenido, $img_match)) {
                $img_url = esc_url($img_match[1]);
                $contenido_renderizado .= "<p><strong>🖼 Imagen:</strong><br><a href='$img_url' target='_blank'>$img_url</a></p>";
            } else {
                $contenido_renderizado .= "<p>(No se pudo detectar imagen)</p>";
            }
        }

        if (empty($contenido_renderizado)) {
            $contenido_renderizado = "<p>" . nl2br(strip_tags($contenido)) . "</p>";
        }

        $grupo = groups_get_group(['group_id' => $activity->item_id]);
        $nombre_grupo = $grupo ? esc_html($grupo->name) : 'Grupo desconocido';
        $url_grupo = $grupo ? bp_get_group_permalink($grupo) : '#';

        $user_id = $activity->user_id;
        $autor_nombre = bp_core_get_user_displayname($user_id);
        $autor_link = bp_core_get_userlink($user_id);

        $asunto = "📥 $autor_nombre ha publicado en el grupo "$nombre_grupo"";
        $mensaje = '
            <html><head><meta charset="UTF-8"></head><body>
            <h2>Actividad nueva en el grupo <a href="' . $url_grupo . '">' . $nombre_grupo . '</a></h2>
            <p><strong>Autor:</strong> ' . $autor_link . '</p>
            <div style="background:#f9f9f9;padding:10px;border:1px solid #ccc;margin:10px 0;">' . $contenido_renderizado . '</div>
            <p><a href="' . $url_grupo . '">Ver grupo</a> | ID actividad: ' . $activity->id . '</p>
            </body></html>';

        $headers = ['Content-Type: text/html; charset=UTF-8'];

        $args = [
            'group_id' => $activity->item_id,
            'per_page' => false,
        ];
        $miembros = groups_get_group_members($args);

        $emails = [];
        if (!empty($miembros['members'])) {
            foreach ($miembros['members'] as $miembro) {
                $email = bp_core_get_user_email($miembro->ID);
                if ($email) {
                    $emails[] = $email;
                }
            }
        }

        $admin_email = get_option('admin_email');
        if (!in_array($admin_email, $emails)) {
            $emails[] = $admin_email;
        }

        foreach ($emails as $email) {
            wp_mail($email, $asunto, $mensaje, $headers);
        }

        error_log("✉️ Email enviado a " . count($emails) . " usuarios del grupo "$nombre_grupo" (ID {$activity->item_id})");
    }
});
